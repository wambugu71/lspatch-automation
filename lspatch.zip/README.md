LSPatch: A non-root Xposed framework extending from LSPosed Rootless implementation of LSPosed framework, integrating Xposed API by inserting dex and so into the target APK.Supported Versions Min: Android 9 Max: In theory, same with LSPosed
Original source  "https://github.com/LSPosed/LSPatch"
How to use:
1. Install termux:
    link: https://f-droid.org/en/packages/com.termux/
    
2. termux terminal:
    1. pkg update && pkg upgrade
    2. pkg install openjdk-17
    3. pkg install python
    4. termux-setup-storage
3. download lspatch.zip
4. create a folder lspatch in your phone storage  and unzip the zip
 
4. cd /sdcard/lspatch

5. bash ken.sh

then follow the procedures 


    
 